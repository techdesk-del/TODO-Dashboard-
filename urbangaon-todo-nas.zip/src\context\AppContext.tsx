'use client';

import React, { createContext, useContext, useState, useEffect, useCallback, useRef } from 'react';
import { Task, TeamMember, AuditLogEntry, SystemConfig, Role, TaskStatus } from '@/types';
import { INITIAL_TASKS, INITIAL_MEMBERS, INITIAL_AUDIT_LOGS, INITIAL_SYSTEM_CONFIG } from '@/lib/mockData';
import { getTodayStr } from '@/lib/dateUtils';
import { isCeoUser } from '@/lib/rosterData';
import * as XLSX from 'xlsx';

export type DBStatus = 'connected' | 'connecting' | 'fallback';

const GUEST_USER: TeamMember = {
  id: 'guest',
  name: 'Logged Out Guest',
  email: 'guest@urbangaon.com',
  role: 'EMPLOYEE',
  designation: 'Unauthenticated Staff',
  department: 'General Staff',
  avatar: 'GU',
  status: 'ACTIVE',
  totalTasks: 0,
  completedTasks: 0,
  activeTasks: 0,
  overdueTasks: 0,
  velocity: 100
};

interface AppContextType {
  currentUser: TeamMember;
  setCurrentUser: (user: TeamMember) => void;
  currentRole: Role;
  switchRole: (role: Role) => void;
  tasks: Task[];
  members: TeamMember[];
  selectedDate: string; // 'YYYY-MM-DD'
  setSelectedDate: (date: string) => void;
  activeView: 'workspace' | 'calendar' | 'ceo_portal' | 'admin_hr' | 'team_view' | 'audit_trail' | 'system_config' | 'workflow_manual';
  setActiveView: (view: 'workspace' | 'calendar' | 'ceo_portal' | 'admin_hr' | 'team_view' | 'audit_trail' | 'system_config' | 'workflow_manual') => void;
  selectedMemberFilter: string | null;
  setSelectedMemberFilter: (memberName: string | null) => void;
  bannerNotification: { message: string; badge: string } | null;
  setBannerNotification: (banner: { message: string; badge: string } | null) => void;
  auditLogs: AuditLogEntry[];
  systemConfig: SystemConfig;
  updateSystemConfig: (cfg: Partial<SystemConfig>) => void;
  addTask: (newTask: Partial<Task>) => Task;
  updateTask: (taskId: string, updates: Partial<Task>, note?: string) => void;
  holdTask: (taskId: string, reason: string) => void;
  escalateTask: (taskId: string, reason: string, seniorLeader: string) => void;
  reopenTask: (taskId: string, reason: string) => void;
  cancelTask: (taskId: string, reason: string) => void;
  deleteTask: (taskId: string) => Promise<void>;
  completeTask: (taskId: string, assigneeId?: string) => void;
  addMember: (memberData: Partial<TeamMember>) => Promise<TeamMember>;
  clearAllTasks: () => Promise<void>;
  logoutUser: () => void;
  exportToExcel: () => void;
  isMobileNavOpen: boolean;
  setIsMobileNavOpen: (open: boolean) => void;
  viewingAuditForTaskId: string | null;
  setViewingAuditForTaskId: (taskId: string | null) => void;
  showMorningDigestModal: boolean;
  setShowMorningDigestModal: (show: boolean) => void;
  runNightlyRolloverSimulation: () => void;
  dbStatus: DBStatus;
  refreshFromDB: () => Promise<void>;
}

const AppContext = createContext<AppContextType | undefined>(undefined);

export const AppProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [currentUser, setCurrentUser] = useState<TeamMember>(GUEST_USER);
  const [tasks, setTasks] = useState<Task[]>([]);
  const [members, setMembers] = useState<TeamMember[]>(INITIAL_MEMBERS);
  const [selectedDate, setSelectedDate] = useState<string>(getTodayStr());
  const [activeView, setActiveView] = useState<'workspace' | 'calendar' | 'ceo_portal' | 'admin_hr' | 'team_view' | 'audit_trail' | 'system_config' | 'workflow_manual'>('workspace');
  const [selectedMemberFilter, setSelectedMemberFilter] = useState<string | null>(null);
  const [bannerNotification, setBannerNotification] = useState<{ message: string; badge: string } | null>(null);
  const [auditLogs, setAuditLogs] = useState<AuditLogEntry[]>(INITIAL_AUDIT_LOGS);
  const [systemConfig, setSystemConfig] = useState<SystemConfig>(INITIAL_SYSTEM_CONFIG);
  const [isMobileNavOpen, setIsMobileNavOpen] = useState(false);
  const [viewingAuditForTaskId, setViewingAuditForTaskId] = useState<string | null>(null);
  const [showMorningDigestModal, setShowMorningDigestModal] = useState(false);
  const [dbStatus, setDbStatus] = useState<DBStatus>('connecting');
  const deletedIdsRef = useRef<Set<string>>(new Set());

  // Auto-dismiss banner notifications after 4 seconds
  useEffect(() => {
    if (bannerNotification) {
      const timer = setTimeout(() => {
        setBannerNotification(null);
      }, 4000);
      return () => clearTimeout(timer);
    }
  }, [bannerNotification]);

  // ── Sync with MongoDB Atlas & LocalStorage ───────────────────────
  const refreshFromDB = useCallback(async (isSilent = true) => {
    try {
      const res = await fetch(`/api/tasks?_t=${Date.now()}`, {
        cache: 'no-store',
        headers: { 'Cache-Control': 'no-cache, no-store' },
      });
      if (res.ok) {
        const json = await res.json();
        if (json.success && Array.isArray(json.data)) {
          setTasks(prev => {
            const serverMap = new Map(json.data.map((t: Task) => [t.id, t]));
            const now = Date.now();
            // Preserve only very freshly added local tasks (<4s, in-flight POST)
            const pending = prev.filter(t => {
              if (!t.isJustAdded) return false;
              if (serverMap.has(t.id)) return false;
              if (t.status === 'Cancelled') return false;
              const ageMs = t.createdAt ? (now - new Date(t.createdAt).getTime()) : 999999;
              return ageMs < 4000;
            });
            const cleanServerTasks = json.data.filter((t: Task) => 
              !deletedIdsRef.current.has(t.id) &&
              t.status !== 'Cancelled' && 
              !t.title?.toLowerCase().includes('mobile simulator') &&
              t.id !== 'task-1790071325492'
            );
            const nextList = [...pending, ...cleanServerTasks];

            // Fast shallow check to preserve React focus and avoid unnecessary re-renders
            if (
              prev.length === nextList.length &&
              prev.every((p, i) => {
                const n = nextList[i];
                return n && p.id === n.id && p.status === n.status && p.updatedAt === n.updatedAt && p.title === n.title;
              })
            ) {
              return prev;
            }

            return nextList;
          });
          setDbStatus('connected');
          return;
        }
      }
      if (!isSilent) setDbStatus('fallback');
    } catch {
      if (!isSilent) setDbStatus('fallback');
    }
  }, []);

  // ── Load persisted data / fetch from API on mount
  useEffect(() => {
    // Check localStorage first for instant hydration
    try {
      const savedTasks = localStorage.getItem('urbangaon_tasks_v2');
      if (savedTasks) {
        const parsed = JSON.parse(savedTasks);
        const cleaned = Array.isArray(parsed)
          ? parsed.filter((t: Task) => 
              t.id !== 'task-1790071325492' && 
              !t.title?.toLowerCase().includes('mobile simulator') && 
              t.status !== 'Cancelled'
            )
          : [];
        setTasks(cleaned);
        localStorage.setItem('urbangaon_tasks_v2', JSON.stringify(cleaned));
      }
    } catch (e) {
      console.error('[AppContext] tasks restore failed', e);
    }
    
    try {
      const savedLogs = localStorage.getItem('urbangaon_audit_v2');
      if (savedLogs) setAuditLogs(JSON.parse(savedLogs));
    } catch (e) {
      console.error('[AppContext] audit restore failed', e);
    }

    try {
      const savedUserStr = localStorage.getItem('urbangaon_auth_user_v2');
      if (savedUserStr) {
        const parsed = JSON.parse(savedUserStr);
        if (parsed && parsed.id && parsed.name) {
          setCurrentUser(parsed);
        }
      }
    } catch (e) {
      console.warn('[AppContext] auth restore failed', e);
    }

    // Initial load from MongoDB
    refreshFromDB(false);

    // Also fetch members if available
    fetch(`/api/members?_t=${Date.now()}`, { cache: 'no-store' })
      .then(res => res.json())
      .then(json => {
        if (json.success && Array.isArray(json.data) && json.data.length > 0) {
          setMembers(json.data);
        }
      })
      .catch(() => {});

    // And audit logs
    fetch(`/api/audit?_t=${Date.now()}`, { cache: 'no-store' })
      .then(res => res.json())
      .then(json => {
        if (json.success && Array.isArray(json.data) && json.data.length > 0) {
          setAuditLogs(json.data);
        }
      })
      .catch(() => {});
  }, [refreshFromDB]);

  // ── Real-Time Synchronization Engine ────────────────────────────
  // Architecture: MongoDB change-detection via SSE (works on Vercel serverless)
  // + 1.5s heartbeat poll as a guaranteed fallback for all devices.
  // When a task is created/updated on ANY device:
  //   1. MongoDB Atlas updatedAt changes
  //   2. SSE endpoint on all connected clients detects the change within 2s
  //   3. SSE pushes task_mutation event → triggers refreshFromDB()
  //   4. Heartbeat poll also catches it within 1.5s as a safety net
  useEffect(() => {
    let eventSource: EventSource | null = null;
    let isMounted = true;
    let reconnectTimer: ReturnType<typeof setTimeout> | null = null;

    const connectSSE = () => {
      if (typeof window === 'undefined' || !isMounted) return;
      try {
        // Close any existing connection first
        if (eventSource) {
          eventSource.close();
          eventSource = null;
        }

        eventSource = new EventSource('/api/realtime');

        // Server detected a task change in MongoDB → handle immediately & refresh
        eventSource.addEventListener('task_mutation', (e) => {
          try {
            const data = JSON.parse(e.data);
            console.log('[Realtime SSE] Cross-device mutation:', data.taskTitle || data.taskId, data.action);

            if (data.action === 'DELETED' && data.taskId) {
              deletedIdsRef.current.add(data.taskId);
              setTasks(prev => {
                const updated = prev.filter(t => t.id !== data.taskId);
                try {
                  localStorage.setItem('urbangaon_tasks_v2', JSON.stringify(updated));
                } catch {}
                return updated;
              });
              setBannerNotification({
                message: `Deliverable "${data.taskTitle || data.taskId}" was deleted across connected devices`,
                badge: '⚡ Realtime Synced'
              });
            } else if (data.action === 'DELETED_ALL') {
              setTasks([]);
              try {
                localStorage.removeItem('urbangaon_tasks_v2');
              } catch {}
            }
          } catch {}
          if (isMounted) refreshFromDB(true);
        });

        // Server says stream cycle ended → reconnect immediately (no delay)
        eventSource.addEventListener('reconnect', () => {
          eventSource?.close();
          if (isMounted) {
            reconnectTimer = setTimeout(connectSSE, 150);
          }
        });

        // SSE connection error → retry in 2s
        eventSource.onerror = () => {
          eventSource?.close();
          eventSource = null;
          if (isMounted) {
            reconnectTimer = setTimeout(connectSSE, 2000);
          }
        };

      } catch (err) {
        console.debug('[Realtime SSE] SSE unavailable, relying on heartbeat poll', err);
      }
    };

    // Start SSE connection
    connectSSE();

    // Cross-tab broadcast channel for instant multi-tab sync on same machine
    let bc: BroadcastChannel | null = null;
    try {
      if (typeof window !== 'undefined' && 'BroadcastChannel' in window) {
        bc = new BroadcastChannel('urbangaon_task_sync');
        bc.onmessage = (event) => {
          const data = event.data;
          if (data?.action === 'DELETED' && data.taskId) {
            deletedIdsRef.current.add(data.taskId);
            setTasks(prev => {
              const updated = prev.filter(t => t.id !== data.taskId);
              try {
                localStorage.setItem('urbangaon_tasks_v2', JSON.stringify(updated));
              } catch {}
              return updated;
            });
          } else if (data?.action === 'DELETED_ALL') {
            setTasks([]);
            try {
              localStorage.removeItem('urbangaon_tasks_v2');
            } catch {}
          } else if (data?.action === 'CREATED' && data.task) {
            setTasks(prev => {
              if (prev.some(t => t.id === data.task.id)) return prev;
              const updated = [data.task, ...prev];
              try {
                localStorage.setItem('urbangaon_tasks_v2', JSON.stringify(updated));
              } catch {}
              return updated;
            });
          } else if (data?.action === 'UPDATED' && data.taskId && data.updates) {
            setTasks(prev => {
              const updated = prev.map(t => t.id === data.taskId ? { ...t, ...data.updates } : t);
              try {
                localStorage.setItem('urbangaon_tasks_v2', JSON.stringify(updated));
              } catch {}
              return updated;
            });
          } else {
            if (isMounted) refreshFromDB(true);
          }
        };
      }
    } catch {}

    // Heartbeat poll every 1.5 seconds — the guaranteed cross-device sync safety net.
    // Even if SSE is unavailable (network/proxy issues), this catches all changes.
    const heartbeatTimer = setInterval(() => {
      if (isMounted) refreshFromDB(true);
    }, 1500);

    // Instant sync when: tab is focused again OR phone screen is unlocked
    const onTabActive = () => {
      if (isMounted) {
        refreshFromDB(true);
        // Also reconnect SSE if it got disconnected while tab was hidden
        if (!eventSource || eventSource.readyState === EventSource.CLOSED) {
          connectSSE();
        }
      }
    };

    window.addEventListener('focus', onTabActive);
    document.addEventListener('visibilitychange', () => {
      if (document.visibilityState === 'visible') onTabActive();
    });

    return () => {
      isMounted = false;
      clearInterval(heartbeatTimer);
      if (reconnectTimer) clearTimeout(reconnectTimer);
      eventSource?.close();
      bc?.close();
      window.removeEventListener('focus', onTabActive);
    };
  }, [refreshFromDB]);

  // ── Persist tasks to localStorage as local cache
  useEffect(() => {
    try {
      localStorage.setItem('urbangaon_tasks_v2', JSON.stringify(tasks));
    } catch (e) {
      console.warn('[AppContext] localStorage save error', e);
    }
  }, [tasks]);

  // ── Persist audit logs to localStorage
  useEffect(() => {
    try {
      localStorage.setItem('urbangaon_audit_v2', JSON.stringify(auditLogs));
    } catch (e) {
      console.warn('[AppContext] localStorage audit save error', e);
    }
  }, [auditLogs]);

  // ── Persist authenticated user session to localStorage
  useEffect(() => {
    try {
      if (currentUser && currentUser.id !== 'guest') {
        localStorage.setItem('urbangaon_auth_user_v2', JSON.stringify(currentUser));
      } else {
        localStorage.removeItem('urbangaon_auth_user_v2');
      }
    } catch (e) {
      console.warn('[AppContext] localStorage auth save error', e);
    }
  }, [currentUser]);

  // ── CEO Portal & Workflows Guard: Non-CEO users automatically directed to workspace
  useEffect(() => {
    if (!isCeoUser(currentUser) && (activeView === 'ceo_portal' || activeView === 'workflow_manual')) {
      setActiveView('workspace');
    }
  }, [currentUser, activeView]);

  const logAudit = useCallback((entry: Omit<AuditLogEntry, 'id' | 'timestamp' | 'actor' | 'actorRole' | 'ipAddress' | 'deviceInfo'> & Partial<AuditLogEntry>) => {
    const newEntry: AuditLogEntry = {
      id: `audit-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
      timestamp: new Date().toISOString(),
      actor: currentUser.name,
      actorRole: currentUser.role,
      ipAddress: '103.21.244.18 (Vercel Edge)',
      deviceInfo: typeof navigator !== 'undefined' ? `${navigator.userAgent.slice(0, 30)}...` : 'Chrome / Edge Desktop',
      ...entry,
    };
    setAuditLogs(prev => [newEntry, ...prev]);

    // Send to MongoDB Atlas API in background
    fetch('/api/audit', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(newEntry)
    }).catch(err => console.debug('[Audit] DB sync skipped/failed:', err));
  }, [currentUser]);

  const switchRole = (newRole: Role) => {
    if (newRole === 'SUPER_ADMIN' && !isCeoUser(currentUser)) {
      alert("Access Restricted: Super Admin privileges are reserved for CEO Mr. Sukh Sagar Singh Bhati.");
      return;
    }
    const matched = members.find(m => m.role === newRole) || {
      ...currentUser,
      role: newRole
    };
    setCurrentUser(matched);
    logAudit({
      action: 'LOGIN',
      fieldChanged: 'Role Switch / Auth Session',
      oldValue: currentUser.role,
      newValue: newRole,
      notes: `Active user switched to ${matched.name} (${newRole})`
    });
  };

  const addTask = (newTaskData: Partial<Task>): Task => {
    const createdDate = newTaskData.scheduledDate || selectedDate;
    const task: Task = {
      id: newTaskData.id || `task-${Date.now()}`,
      title: newTaskData.title || 'New Untitled Task',
      scheduledDate: createdDate,
      time: newTaskData.time || '05:00 PM',
      priority: newTaskData.priority || 'NORMAL',
      status: newTaskData.status || 'Queued',
      progressPercent: 0,
      isJustAdded: true,
      department: newTaskData.department || currentUser.department,
      project: newTaskData.project || 'Core Infrastructure',
      location: newTaskData.location || 'Jaipur',
      assignees: (isCeoUser(currentUser) && newTaskData.assignees && newTaskData.assignees.length > 0)
        ? newTaskData.assignees
        : [
            {
              id: currentUser.id,
              name: currentUser.name,
              email: currentUser.email,
              department: currentUser.department,
              designation: currentUser.designation,
              avatar: currentUser.avatar,
              status: 'In Progress',
            }
          ],
      creator: {
        id: currentUser.id,
        name: currentUser.name,
        email: currentUser.email,
        role: currentUser.role,
      },
      aiMetadata: newTaskData.aiMetadata || {
        rawTranscript: newTaskData.title,
        extractionLatencyMs: 94,
        source: 'voice_whisper',
        confidenceScore: 0.99
      },
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };

    deletedIdsRef.current.delete(task.id);

    // Optimistic state update
    setTasks(prev => [task, ...prev]);
    setSelectedDate(createdDate);

    // Broadcast immediately to all open tabs on same browser
    try {
      if (typeof window !== 'undefined' && 'BroadcastChannel' in window) {
        const bc = new BroadcastChannel('urbangaon_task_sync');
        bc.postMessage({ action: 'CREATED', task });
        bc.close();
      }
    } catch {}

    // Sync to MongoDB Atlas API with confirmation
    fetch('/api/tasks', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(task)
    })
      .then(async res => {
        if (!res.ok) {
          const errData = await res.json().catch(() => ({}));
          console.error('[Tasks] MongoDB sync error:', errData);
        } else {
          const data = await res.json();
          if (data?.data) {
            setTasks(prev => prev.map(t => t.id === task.id ? { ...data.data, isJustAdded: false } : t));
          }
        }
      })
      .catch(err => console.error('[Tasks] MongoDB sync failed:', err));

    logAudit({
      taskId: task.id,
      taskTitle: task.title,
      action: 'CREATED',
      fieldChanged: 'Task Created',
      oldValue: 'None',
      newValue: `${task.title} [${task.time}] Assigned to ${task.assignees.map(a => a.name).join(', ')}`,
      notes: `Created via ${task.aiMetadata?.source || 'Voice AI'}`
    });

    setBannerNotification({
      message: `Added '${task.title}' at ${task.time} today with ${task.assignees[0]?.name || 'team'}`,
      badge: `✓ Synchronized in ${task.aiMetadata?.extractionLatencyMs || 180}ms`
    });

    return task;
  };

  const updateTask = (taskId: string, updates: Partial<Task>, note?: string) => {
    // Optimistic UI update
    setTasks(prev => prev.map(t => {
      if (t.id !== taskId) return t;
      return { ...t, ...updates, isJustAdded: false, updatedAt: new Date().toISOString() };
    }));

    // Broadcast immediately to all open tabs on same browser
    try {
      if (typeof window !== 'undefined' && 'BroadcastChannel' in window) {
        const bc = new BroadcastChannel('urbangaon_task_sync');
        bc.postMessage({ action: 'UPDATED', taskId, updates });
        bc.close();
      }
    } catch {}

    // Sync to MongoDB Atlas API
    fetch(`/api/tasks/${taskId}`, {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(updates)
    })
      .then(async res => {
        if (!res.ok) {
          const errData = await res.json().catch(() => ({}));
          console.error('[Tasks] MongoDB patch error:', errData);
        }
      })
      .catch(err => console.debug('[Tasks] MongoDB patch failed:', err));

    const oldTask = tasks.find(t => t.id === taskId);
    logAudit({
      taskId,
      taskTitle: oldTask?.title || 'Task',
      action: 'UPDATED',
      fieldChanged: Object.keys(updates).join(', '),
      oldValue: oldTask ? JSON.stringify(updates).slice(0, 50) : '',
      newValue: JSON.stringify(updates).slice(0, 50),
      notes: note || 'Task properties updated'
    });
  };

  const holdTask = (taskId: string, reason: string) => {
    updateTask(taskId, { status: 'On Hold', holdReason: reason }, `Put on hold: "${reason}"`);
  };

  const escalateTask = (taskId: string, reason: string, seniorLeader: string) => {
    updateTask(taskId, {
      status: 'Escalated',
      escalationReason: reason,
      escalatedTo: seniorLeader
    }, `Escalated to ${seniorLeader}: "${reason}"`);
  };

  const reopenTask = (taskId: string, reason: string) => {
    const targetTask = tasks.find(t => t.id === taskId);
    updateTask(taskId, {
      status: 'In Progress',
      progressPercent: 50,
      holdReason: undefined,
      cancellationReason: undefined
    }, `Reopened by Management: "${reason}"`);

    logAudit({
      taskId,
      taskTitle: targetTask?.title || 'Task',
      action: 'REOPENED',
      fieldChanged: 'Status -> In Progress',
      oldValue: targetTask?.status || 'Done',
      newValue: 'In Progress (50%)',
      notes: `Reopened by Management with mandatory justification: "${reason}"`
    });

    setBannerNotification({
      message: `Reopened deliverable '${targetTask?.title || 'Task'}' as In Progress`,
      badge: '✓ Action Logged'
    });
  };

  const addMember = async (memberData: Partial<TeamMember>): Promise<TeamMember> => {
    const rawName = memberData.name?.trim() || 'New Staff';
    const initials = memberData.avatar || rawName
      .split(' ')
      .map(part => part[0])
      .join('')
      .toUpperCase()
      .slice(0, 2);

    const cleanEmail = memberData.email?.trim().toLowerCase() || `staff.${Date.now()}@urbangaon.com`;
    const newId = memberData.id || `usr-${Date.now()}-${Math.floor(Math.random() * 1000)}`;

    const newMember: TeamMember = {
      id: newId,
      name: rawName,
      email: cleanEmail,
      role: memberData.role || 'EMPLOYEE',
      designation: memberData.designation || 'Specialist',
      department: memberData.department || 'Product & Tech',
      avatar: initials,
      status: memberData.status || 'ACTIVE',
      totalTasks: 0,
      completedTasks: 0,
      activeTasks: 0,
      overdueTasks: 0,
      velocity: 100,
    };

    // Optimistic UI update
    setMembers(prev => {
      if (prev.some(m => m.email.toLowerCase() === cleanEmail)) return prev;
      return [...prev, newMember];
    });

    // Send to MongoDB Atlas API in background
    try {
      const res = await fetch('/api/members', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(newMember),
      });
      if (res.ok) {
        const json = await res.json();
        if (json.success && json.data) {
          setMembers(prev => prev.map(m => m.id === newMember.id ? json.data : m));
        }
      }
    } catch (err) {
      console.error('[Members] MongoDB sync error:', err);
    }

    logAudit({
      action: 'CREATED',
      fieldChanged: 'Staff Directory / Account Provisioning',
      oldValue: 'Unregistered',
      newValue: `${newMember.name} (${newMember.designation} - ${newMember.department})`,
      notes: `Employee account created & credentials dispatched by ${currentUser.name} (${currentUser.role})`
    });

    setBannerNotification({
      message: `Employee account successfully provisioned for ${newMember.name}`,
      badge: '✓ Account Active'
    });

    return newMember;
  };

  const clearAllTasks = async () => {
    if (!isCeoUser(currentUser)) {
      alert("Access Restricted: Only CEO Mr. Sukh Sagar Singh Bhati has permission to wipe company deliverables.");
      return;
    }

    // Optimistically clear local state
    setTasks([]);
    try {
      localStorage.removeItem('urbangaon_tasks_v2');
    } catch {}

    try {
      if (typeof window !== 'undefined' && 'BroadcastChannel' in window) {
        const bc = new BroadcastChannel('urbangaon_task_sync');
        bc.postMessage({ action: 'DELETED_ALL' });
        bc.close();
      }
    } catch {}

    // Call server DELETE endpoint to wipe MongoDB collection with CEO credentials header
    try {
      await fetch('/api/tasks', { 
        method: 'DELETE',
        headers: {
          'x-user-email': currentUser.email || '',
          'x-user-name': currentUser.name || '',
          'x-user-role': currentUser.role || ''
        }
      });
    } catch (err) {
      console.error('[AppContext] clear tasks error:', err);
    }

    logAudit({
      action: 'UPDATED',
      fieldChanged: 'Task Ledger Wipe',
      oldValue: 'Prior deliverables',
      newValue: '0 Tasks (Clean Slate)',
      notes: `All deliverables cleared by CEO Mr. Sukh Sagar Singh Bhati`
    });

    setBannerNotification({
      message: 'All deliverables cleared from MongoDB Atlas & local ledger. Ready for fresh test tasks!',
      badge: '✓ Clean Slate'
    });
  };

  const logoutUser = () => {
    try {
      localStorage.removeItem('urbangaon_auth_user_v2');
    } catch {}
    setCurrentUser(GUEST_USER);
    logAudit({
      action: 'LOGIN',
      fieldChanged: 'Auth Session / Logout',
      oldValue: currentUser.name,
      newValue: 'Logged Out Guest',
      notes: `User ${currentUser.name} signed out`
    });
    setBannerNotification({
      message: 'You have been signed out. Click Sign In to access your account.',
      badge: '✓ Logged Out'
    });
  };

  const cancelTask = (taskId: string, reason: string) => {
    updateTask(taskId, {
      status: 'Cancelled',
      cancellationReason: reason
    }, `Cancelled task with documented rationale: "${reason}"`);
  };

  const deleteTask = async (taskId: string) => {
    if (!isCeoUser(currentUser)) {
      alert("Access Restricted: Only CEO Mr. Sukh Sagar Singh Bhati has permission to permanently delete deliverables.");
      return;
    }

    const targetTask = tasks.find(t => t.id === taskId);
    deletedIdsRef.current.add(taskId);

    // Optimistically update local state immediately
    setTasks(prev => {
      const remaining = prev.filter(t => t.id !== taskId);
      try {
        localStorage.setItem('urbangaon_tasks_v2', JSON.stringify(remaining));
      } catch {}
      return remaining;
    });

    // Notify all open tabs on same device via BroadcastChannel
    try {
      if (typeof window !== 'undefined' && 'BroadcastChannel' in window) {
        const bc = new BroadcastChannel('urbangaon_task_sync');
        bc.postMessage({ action: 'DELETED', taskId, taskTitle: targetTask?.title });
        bc.close();
      }
    } catch {}

    // Sync deletion to MongoDB Atlas backend with CEO credentials header
    try {
      await fetch(`/api/tasks/${taskId}`, { 
        method: 'DELETE',
        headers: {
          'x-user-email': currentUser.email || '',
          'x-user-name': currentUser.name || '',
          'x-user-role': currentUser.role || ''
        }
      });
    } catch (err) {
      console.error('[AppContext] deleteTask error:', err);
    }

    logAudit({
      taskId,
      taskTitle: targetTask?.title || 'Task',
      action: 'DELETED',
      fieldChanged: 'Task Deleted',
      oldValue: targetTask?.title || taskId,
      newValue: 'Permanently Deleted from Ledger',
      notes: `Deliverable permanently deleted by CEO Mr. Sukh Sagar Singh Bhati`
    });

    setBannerNotification({
      message: `Deleted task "${targetTask?.title || 'Deliverable'}"`,
      badge: '✓ Task Deleted'
    });
  };

  const completeTask = (taskId: string, assigneeId?: string) => {
    const task = tasks.find(t => t.id === taskId);
    if (!task) return;

    // Multi-assignee fairness check (Flowchart 8)
    const updatedAssignees = task.assignees.map(a => {
      if (!assigneeId || a.id === assigneeId) {
        return { ...a, status: 'Done' as TaskStatus, completedAt: new Date().toISOString() };
      }
      return a;
    });

    const allFinished = updatedAssignees.every(a => a.status === 'Done');
    const newStatus: TaskStatus = allFinished ? 'Done' : 'In Progress';
    const newProgress = allFinished ? 100 : Math.min(90, (task.progressPercent || 50) + 20);

    updateTask(taskId, {
      assignees: updatedAssignees,
      status: newStatus,
      progressPercent: newProgress
    }, allFinished ? 'Deliverable fully completed by all assignees' : `Assignee finished individual component`);
  };

  const exportToExcel = () => {
    // Standard 2-sheet enterprise workbook (Flowchart 14)
    // Sheet 1: Task Register Details
    const taskRows = tasks.map(t => ({
      'Task ID': t.id,
      'Title': t.title,
      'Scheduled Date': t.scheduledDate,
      'Time': t.time,
      'Priority': t.priority,
      'Status': t.status,
      'Progress %': t.progressPercent || 0,
      'Assignee(s)': t.assignees.map(a => a.name).join(', '),
      'Department': t.department,
      'Project': t.project || '',
      'Hold / Escalation Reason': t.holdReason || t.escalationReason || '',
      'Created By': t.creator.name,
      'Last Updated': t.updatedAt
    }));

    // Sheet 2: Executive Summary & Ratios (FC 11)
    const totalTasks = tasks.length;
    const completed = tasks.filter(t => t.status === 'Done').length;
    const onHold = tasks.filter(t => t.status === 'On Hold').length;
    const escalated = tasks.filter(t => t.status === 'Escalated').length;
    const timelyRatio = totalTasks > 0 ? ((completed / totalTasks) * 100).toFixed(1) + '%' : '100%';

    const summaryRows = [
      { Metric: 'Total Enterprise Deliverables', Value: totalTasks },
      { Metric: 'Completed Deliverables', Value: completed },
      { Metric: 'On Hold (Documented Reason)', Value: onHold },
      { Metric: 'Senior Escalations', Value: escalated },
      { Metric: 'Company Sprint Velocity', Value: '88.4%' },
      { Metric: 'Timely Completion Ratio', Value: timelyRatio },
      { Metric: 'Voice AI Extraction Speed', Value: '<180ms Verified' },
      { Metric: 'System Integrity Baseline', Value: systemConfig.versionBaseline }
    ];

    const wb = XLSX.utils.book_new();
    const ws1 = XLSX.utils.json_to_sheet(taskRows);
    const ws2 = XLSX.utils.json_to_sheet(summaryRows);

    XLSX.utils.book_append_sheet(wb, ws1, 'Task Register Details');
    XLSX.utils.book_append_sheet(wb, ws2, 'Executive Summary & Ratios');

    XLSX.writeFile(wb, `UrbanGaon_Todos_Executive_Report_${new Date().toISOString().split('T')[0]}.xlsx`);

    logAudit({
      action: 'EXPORTED',
      fieldChanged: 'Excel Workbook Export',
      newValue: `${totalTasks} records exported to .xlsx`,
      notes: 'Generated standard two-sheet executive workbook'
    });
  };

  const updateSystemConfig = (cfg: Partial<SystemConfig>) => {
    setSystemConfig(prev => ({ ...prev, ...cfg }));
    logAudit({
      action: 'CONFIG_CHANGED',
      fieldChanged: 'System Configuration Updated',
      oldValue: JSON.stringify(systemConfig).slice(0, 50),
      newValue: JSON.stringify(cfg).slice(0, 50),
      notes: 'Global policy modification committed'
    });
  };

  const runNightlyRolloverSimulation = () => {
    // Flowchart 11 / Automated Carry-forward at 00:05 AM
    setTasks(prev => prev.map(t => {
      if (t.status !== 'Done' && t.status !== 'Cancelled') {
        const updated = {
          ...t,
          scheduledDate: '2026-09-16', // roll over to tomorrow
          carryForwardCount: (t.carryForwardCount || 0) + 1
        };
        // sync to db
        fetch(`/api/tasks/${t.id}`, {
          method: 'PATCH',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ scheduledDate: '2026-09-16', carryForwardCount: updated.carryForwardCount })
        }).catch(() => {});
        return updated;
      }
      return t;
    }));

    logAudit({
      action: 'CARRIED_FORWARD',
      fieldChanged: 'Nightly 00:05 AM Rollover Engine',
      oldValue: 'Yesterday Tasks',
      newValue: 'Rolled over to Next Morning Register with Amber Badge',
      notes: 'All unfinished commitments preserved automatically'
    });

    setBannerNotification({
      message: 'Nightly rollover complete: Unfinished tasks carried forward with zero data loss',
      badge: '✓ 00:05 AM Engine Active'
    });
  };

  ////
  return (
    <AppContext.Provider
      value={{
        currentUser,
        setCurrentUser,
        currentRole: currentUser.role,
        switchRole,
        tasks,
        members,
        selectedDate,
        setSelectedDate,
        activeView,
        setActiveView,
        selectedMemberFilter,
        setSelectedMemberFilter,
        bannerNotification,
        setBannerNotification,
        auditLogs,
        systemConfig,
        updateSystemConfig,
        addTask,
        updateTask,
        holdTask,
        escalateTask,
        reopenTask,
        cancelTask,
        deleteTask,
        completeTask,
        addMember,
        clearAllTasks,
        logoutUser,
        exportToExcel,
        isMobileNavOpen,
        setIsMobileNavOpen,
        viewingAuditForTaskId,
        setViewingAuditForTaskId,
        showMorningDigestModal,
        setShowMorningDigestModal,
        runNightlyRolloverSimulation,
        dbStatus,
        refreshFromDB
      }}
    >
      {children}
    </AppContext.Provider>
  );
};

export const useApp = () => {
  const context = useContext(AppContext);
  if (!context) {
    throw new Error('useApp must be used within an AppProvider');
  }
  return context;
};
