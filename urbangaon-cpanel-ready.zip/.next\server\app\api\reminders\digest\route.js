(()=>{var a={};a.id=302,a.ids=[302],a.modules={261:a=>{"use strict";a.exports=require("next/dist/shared/lib/router/utils/app-paths")},3295:a=>{"use strict";a.exports=require("next/dist/server/app-render/after-task-async-storage.external.js")},10846:a=>{"use strict";a.exports=require("next/dist/compiled/next-server/app-page.runtime.prod.js")},11664:(a,b,c)=>{"use strict";c.d(b,{v:()=>g});var d=c(56037),e=c.n(d);let f=new d.Schema({id:{type:String,required:!0,unique:!0,index:!0},timestamp:{type:String,required:!0},taskId:{type:String,index:!0},taskTitle:{type:String},action:{type:String,required:!0,enum:["CREATED","UPDATED","REOPENED","CANCELLED","ESCALATED","CARRIED_FORWARD","EXPORTED","LOGIN","CONFIG_CHANGED","DELETED"]},fieldChanged:{type:String},oldValue:{type:String},newValue:{type:String},actor:{type:String,required:!0},actorRole:{type:String,required:!0},ipAddress:{type:String,required:!0},deviceInfo:{type:String,required:!0},notes:{type:String}},{timestamps:!1,versionKey:!1});f.index({taskId:1,timestamp:-1}),f.index({actor:1,timestamp:-1}),f.index({action:1}),e().models&&e().models.AuditLog&&delete e().models.AuditLog;let g=e().model("AuditLog",f)},16114:(a,b,c)=>{"use strict";c.d(b,{d:()=>j});var d=c(56037),e=c.n(d);let f=new d.Schema({id:{type:String,required:!0},name:{type:String,required:!0},email:{type:String,required:!0},department:{type:String,required:!0},designation:{type:String},avatar:{type:String},status:{type:String,required:!0},completedAt:{type:String},remarks:{type:String}},{_id:!1}),g=new d.Schema({id:{type:String,required:!0},name:{type:String,required:!0},email:{type:String,required:!0},role:{type:String,required:!0}},{_id:!1}),h=new d.Schema({rawTranscript:{type:String},extractionLatencyMs:{type:Number},source:{type:String,enum:["voice_whisper","text_nlp","manual"]},confidenceScore:{type:Number,min:0,max:1}},{_id:!1}),i=new d.Schema({id:{type:String,required:!0,unique:!0,index:!0},title:{type:String,required:!0,trim:!0,maxlength:500},scheduledDate:{type:String,required:!0},time:{type:String,required:!0},priority:{type:String,required:!0,enum:["URGENT","HIGH","NORMAL"]},status:{type:String,required:!0,enum:["Queued","In Progress","Review","Done","On Hold","Escalated","Cancelled"],default:"Queued"},assignees:{type:[f],default:[]},creator:{type:g,required:!0},department:{type:String,required:!0},project:{type:String},location:{type:String},progressPercent:{type:Number,min:0,max:100},isJustAdded:{type:Boolean,default:!1},holdReason:{type:String},escalationReason:{type:String},escalatedTo:{type:String},cancellationReason:{type:String},carryForwardCount:{type:Number,default:0},aiMetadata:{type:h},createdAt:{type:String},updatedAt:{type:String}},{timestamps:!1,versionKey:!1});i.index({scheduledDate:1,status:1}),i.index({"assignees.id":1,scheduledDate:1}),i.index({"creator.id":1,scheduledDate:1}),i.index({priority:1,status:1,scheduledDate:1}),i.index({department:1,scheduledDate:1});let j=e().models.Task||e().model("Task",i)},19121:a=>{"use strict";a.exports=require("next/dist/server/app-render/action-async-storage.external.js")},19509:(a,b,c)=>{"use strict";c.d(b,{B3:()=>e,tF:()=>d,um:()=>f});let d=()=>{let a=new Date,b=a.getFullYear(),c=String(a.getMonth()+1).padStart(2,"0"),d=String(a.getDate()).padStart(2,"0");return`${b}-${c}-${d}`},e=()=>{let a=new Date;a.setDate(a.getDate()+1);let b=a.getFullYear(),c=String(a.getMonth()+1).padStart(2,"0"),d=String(a.getDate()).padStart(2,"0");return`${b}-${c}-${d}`},f=a=>{if(!a)return"";let[b,c,e]=a.split("-").map(Number);if(!b||!c||!e)return a;let f=new Date(b,c-1,e),g=d(),h=f.toLocaleDateString("en-GB",{weekday:"short",day:"numeric",month:"short",year:"numeric"});return a===g?`Today (${h})`:h}},27400:(a,b,c)=>{"use strict";c.r(b),c.d(b,{handler:()=>H,patchFetch:()=>G,routeModule:()=>C,serverHooks:()=>F,workAsyncStorage:()=>D,workUnitAsyncStorage:()=>E});var d={};c.r(d),c.d(d,{POST:()=>B});var e=c(95736),f=c(9117),g=c(4044),h=c(39326),i=c(32324),j=c(261),k=c(54290),l=c(85328),m=c(38928),n=c(46595),o=c(3421),p=c(17679),q=c(41681),r=c(63446),s=c(86439),t=c(51356),u=c(10641),v=c(35552),w=c(16114),x=c(74573),y=c(11664),z=c(82716),A=c(19509);async function B(a){try{await (0,v.A)();let b=await a.json().catch(()=>({})),c=b.email,d=b.name,e=await w.d.find({status:{$ne:"Cancelled"}}).lean().exec(),f=(0,A.tF)(),g=(0,A.um)(f),h=[];h=c?[{name:d||"Team Member",email:c}]:(await x.O.find({status:"ACTIVE"}).lean().exec()).map(a=>({name:a.name,email:a.email}));let i=[];for(let b of h){let c=e.filter(a=>a.assignees.some(a=>a.email===b.email||a.name.toLowerCase().includes(b.name.toLowerCase()))),d=c.filter(a=>a.scheduledDate<f&&"Done"!==a.status),h=c.filter(a=>a.scheduledDate===f&&"Done"!==a.status),j=c.filter(a=>a.scheduledDate>f&&"Done"!==a.status),k=await (0,z.z)({toEmail:b.email,toName:b.name,overdueTasks:d,todayTasks:h,upcomingTasks:j,dateString:g});i.push({email:b.email,...k}),await y.v.create({id:`audit-email-${Date.now()}-${Math.floor(1e3*Math.random())}`,timestamp:new Date().toISOString(),actor:"Automated Dispatcher Engine",actorRole:"SUPER_ADMIN",action:"CONFIG_CHANGED",fieldChanged:"Morning Email Digest Dispatched",oldValue:"Pending Digest",newValue:`Sent to ${b.email} (Overdue: ${d.length}, Today: ${h.length})`,ipAddress:a.headers.get("x-forwarded-for")||"127.0.0.1",deviceInfo:"Node.js SMTP Transporter",notes:k.isTestAccount?`Dispatched via Ethereal test inbox: ${k.previewUrl||"preview ready"}`:`Live SMTP delivered to ${b.email}`})}return u.NextResponse.json({success:!0,count:i.length,results:i,message:`Dispatched digest to ${i.length} recipient(s).`})}catch(b){let a=b instanceof Error?b.message:"Unknown error";return console.error("[API/reminders/digest error]",a),u.NextResponse.json({success:!1,error:a},{status:500})}}let C=new e.AppRouteRouteModule({definition:{kind:f.RouteKind.APP_ROUTE,page:"/api/reminders/digest/route",pathname:"/api/reminders/digest",filename:"route",bundlePath:"app/api/reminders/digest/route"},distDir:".next",relativeProjectDir:"",resolvedPagePath:"D:\\TODO Dashboard  New updated Version\\src\\app\\api\\reminders\\digest\\route.ts",nextConfigOutput:"standalone",userland:d}),{workAsyncStorage:D,workUnitAsyncStorage:E,serverHooks:F}=C;function G(){return(0,g.patchFetch)({workAsyncStorage:D,workUnitAsyncStorage:E})}async function H(a,b,c){var d;let e="/api/reminders/digest/route";"/index"===e&&(e="/");let g=await C.prepare(a,b,{srcPage:e,multiZoneDraftMode:!1});if(!g)return b.statusCode=400,b.end("Bad Request"),null==c.waitUntil||c.waitUntil.call(c,Promise.resolve()),null;let{buildId:u,params:v,nextConfig:w,isDraftMode:x,prerenderManifest:y,routerServerContext:z,isOnDemandRevalidate:A,revalidateOnlyGenerated:B,resolvedPathname:D}=g,E=(0,j.normalizeAppPath)(e),F=!!(y.dynamicRoutes[E]||y.routes[D]);if(F&&!x){let a=!!y.routes[D],b=y.dynamicRoutes[E];if(b&&!1===b.fallback&&!a)throw new s.NoFallbackError}let G=null;!F||C.isDev||x||(G="/index"===(G=D)?"/":G);let H=!0===C.isDev||!F,I=F&&!H,J=a.method||"GET",K=(0,i.getTracer)(),L=K.getActiveScopeSpan(),M={params:v,prerenderManifest:y,renderOpts:{experimental:{cacheComponents:!!w.experimental.cacheComponents,authInterrupts:!!w.experimental.authInterrupts},supportsDynamicResponse:H,incrementalCache:(0,h.getRequestMeta)(a,"incrementalCache"),cacheLifeProfiles:null==(d=w.experimental)?void 0:d.cacheLife,isRevalidate:I,waitUntil:c.waitUntil,onClose:a=>{b.on("close",a)},onAfterTaskError:void 0,onInstrumentationRequestError:(b,c,d)=>C.onRequestError(a,b,d,z)},sharedContext:{buildId:u}},N=new k.NodeNextRequest(a),O=new k.NodeNextResponse(b),P=l.NextRequestAdapter.fromNodeNextRequest(N,(0,l.signalFromNodeResponse)(b));try{let d=async c=>C.handle(P,M).finally(()=>{if(!c)return;c.setAttributes({"http.status_code":b.statusCode,"next.rsc":!1});let d=K.getRootSpanAttributes();if(!d)return;if(d.get("next.span_type")!==m.BaseServerSpan.handleRequest)return void console.warn(`Unexpected root span type '${d.get("next.span_type")}'. Please report this Next.js issue https://github.com/vercel/next.js`);let e=d.get("next.route");if(e){let a=`${J} ${e}`;c.setAttributes({"next.route":e,"http.route":e,"next.span_name":a}),c.updateName(a)}else c.updateName(`${J} ${a.url}`)}),g=async g=>{var i,j;let k=async({previousCacheEntry:f})=>{try{if(!(0,h.getRequestMeta)(a,"minimalMode")&&A&&B&&!f)return b.statusCode=404,b.setHeader("x-nextjs-cache","REVALIDATED"),b.end("This page could not be found"),null;let e=await d(g);a.fetchMetrics=M.renderOpts.fetchMetrics;let i=M.renderOpts.pendingWaitUntil;i&&c.waitUntil&&(c.waitUntil(i),i=void 0);let j=M.renderOpts.collectedTags;if(!F)return await (0,o.I)(N,O,e,M.renderOpts.pendingWaitUntil),null;{let a=await e.blob(),b=(0,p.toNodeOutgoingHttpHeaders)(e.headers);j&&(b[r.NEXT_CACHE_TAGS_HEADER]=j),!b["content-type"]&&a.type&&(b["content-type"]=a.type);let c=void 0!==M.renderOpts.collectedRevalidate&&!(M.renderOpts.collectedRevalidate>=r.INFINITE_CACHE)&&M.renderOpts.collectedRevalidate,d=void 0===M.renderOpts.collectedExpire||M.renderOpts.collectedExpire>=r.INFINITE_CACHE?void 0:M.renderOpts.collectedExpire;return{value:{kind:t.CachedRouteKind.APP_ROUTE,status:e.status,body:Buffer.from(await a.arrayBuffer()),headers:b},cacheControl:{revalidate:c,expire:d}}}}catch(b){throw(null==f?void 0:f.isStale)&&await C.onRequestError(a,b,{routerKind:"App Router",routePath:e,routeType:"route",revalidateReason:(0,n.c)({isRevalidate:I,isOnDemandRevalidate:A})},z),b}},l=await C.handleResponse({req:a,nextConfig:w,cacheKey:G,routeKind:f.RouteKind.APP_ROUTE,isFallback:!1,prerenderManifest:y,isRoutePPREnabled:!1,isOnDemandRevalidate:A,revalidateOnlyGenerated:B,responseGenerator:k,waitUntil:c.waitUntil});if(!F)return null;if((null==l||null==(i=l.value)?void 0:i.kind)!==t.CachedRouteKind.APP_ROUTE)throw Object.defineProperty(Error(`Invariant: app-route received invalid cache entry ${null==l||null==(j=l.value)?void 0:j.kind}`),"__NEXT_ERROR_CODE",{value:"E701",enumerable:!1,configurable:!0});(0,h.getRequestMeta)(a,"minimalMode")||b.setHeader("x-nextjs-cache",A?"REVALIDATED":l.isMiss?"MISS":l.isStale?"STALE":"HIT"),x&&b.setHeader("Cache-Control","private, no-cache, no-store, max-age=0, must-revalidate");let m=(0,p.fromNodeOutgoingHttpHeaders)(l.value.headers);return(0,h.getRequestMeta)(a,"minimalMode")&&F||m.delete(r.NEXT_CACHE_TAGS_HEADER),!l.cacheControl||b.getHeader("Cache-Control")||m.get("Cache-Control")||m.set("Cache-Control",(0,q.getCacheControlHeader)(l.cacheControl)),await (0,o.I)(N,O,new Response(l.value.body,{headers:m,status:l.value.status||200})),null};L?await g(L):await K.withPropagatedContext(a.headers,()=>K.trace(m.BaseServerSpan.handleRequest,{spanName:`${J} ${a.url}`,kind:i.SpanKind.SERVER,attributes:{"http.method":J,"http.target":a.url}},g))}catch(b){if(b instanceof s.NoFallbackError||await C.onRequestError(a,b,{routerKind:"App Router",routePath:E,routeType:"route",revalidateReason:(0,n.c)({isRevalidate:I,isOnDemandRevalidate:A})}),F)throw b;return await (0,o.I)(N,O,new Response(null,{status:500})),null}}},29294:a=>{"use strict";a.exports=require("next/dist/server/app-render/work-async-storage.external.js")},31421:a=>{"use strict";a.exports=require("node:child_process")},35552:(a,b,c)=>{"use strict";c.d(b,{A:()=>g});var d=c(56037),e=c.n(d);let f=global.__mongoCache??{conn:null,promise:null};global.__mongoCache=f;let g=async function(){let a=process.env.MONGODB_URI;if(!a)throw Error("[DB] MONGODB_URI is not defined. Please set MONGODB_URI in your .env.local file.");return f.conn&&1===f.conn.readyState||(f.promise||(f.promise=e().connect(a,{bufferCommands:!1,maxPoolSize:10,serverSelectionTimeoutMS:8e3,socketTimeoutMS:45e3}).then(a=>(console.log("[DB] ✓ Connected to MongoDB Atlas"),a.connection)).catch(a=>{throw console.error("[DB] ✗ Connection failed:",a.message),f.promise=null,a})),f.conn=await f.promise),f.conn}},37067:a=>{"use strict";a.exports=require("node:http")},38522:a=>{"use strict";a.exports=require("node:zlib")},40610:a=>{"use strict";a.exports=require("node:dns")},41692:a=>{"use strict";a.exports=require("node:tls")},44708:a=>{"use strict";a.exports=require("node:https")},44870:a=>{"use strict";a.exports=require("next/dist/compiled/next-server/app-route.runtime.prod.js")},48161:a=>{"use strict";a.exports=require("node:os")},56037:a=>{"use strict";a.exports=require("mongoose")},57075:a=>{"use strict";a.exports=require("node:stream")},57975:a=>{"use strict";a.exports=require("node:util")},63033:a=>{"use strict";a.exports=require("next/dist/server/app-render/work-unit-async-storage.external.js")},73024:a=>{"use strict";a.exports=require("node:fs")},73136:a=>{"use strict";a.exports=require("node:url")},74573:(a,b,c)=>{"use strict";c.d(b,{O:()=>g});var d=c(56037),e=c.n(d);let f=new d.Schema({id:{type:String,required:!0,unique:!0,index:!0},name:{type:String,required:!0,trim:!0},email:{type:String,required:!0,unique:!0,lowercase:!0,trim:!0},role:{type:String,required:!0,enum:["SUPER_ADMIN","ADMIN","MANAGER","EMPLOYEE"]},designation:{type:String,required:!0},department:{type:String,required:!0},avatar:{type:String,default:""},managerId:{type:String},status:{type:String,enum:["ACTIVE","PENDING_HR","ON_LEAVE","DEACTIVATED"],default:"ACTIVE"},totalTasks:{type:Number,default:0},completedTasks:{type:Number,default:0},activeTasks:{type:Number,default:0},overdueTasks:{type:Number,default:0},velocity:{type:Number,default:100}},{timestamps:!1,versionKey:!1});f.index({department:1}),f.index({role:1});let g=e().models.Member||e().model("Member",f)},76760:a=>{"use strict";a.exports=require("node:path")},77030:a=>{"use strict";a.exports=require("node:net")},77598:a=>{"use strict";a.exports=require("node:crypto")},78335:()=>{},78474:a=>{"use strict";a.exports=require("node:events")},82716:(a,b,c)=>{"use strict";c.d(b,{J1:()=>g,z:()=>f});var d=c(1856);async function e(){let a=process.env.SMTP_HOST,b=a&&!a.includes("@")?a:"smtp.gmail.com",c=process.env.SMTP_USER,e=process.env.SMTP_PASS;if(c&&e&&"your_email@gmail.com"!==c)return{transporter:d.Ay.createTransport({host:b,port:Number(process.env.SMTP_PORT)||465,secure:"true"===process.env.SMTP_SECURE||"465"===process.env.SMTP_PORT,auth:{user:c,pass:e},connectionTimeout:8e3,greetingTimeout:5e3,socketTimeout:1e4}),isTestAccount:!1};let f=await d.Ay.createTestAccount();return{transporter:d.Ay.createTransport({host:"smtp.ethereal.email",port:587,secure:!1,auth:{user:f.user,pass:f.pass},connectionTimeout:8e3,greetingTimeout:5e3,socketTimeout:1e4}),isTestAccount:!0}}async function f(a){let b,{transporter:c,isTestAccount:f}=await e(),g=function(a){let{toName:b,overdueTasks:c,todayTasks:d,upcomingTasks:e,dateString:f}=a;return`
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <style>
    body { font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Helvetica, Arial, sans-serif; background-color: #f8fafc; color: #1e293b; margin: 0; padding: 20px; }
    .container { max-width: 600px; margin: 0 auto; background: #ffffff; border-radius: 12px; border: 1px solid #e2e8f0; overflow: hidden; box-shadow: 0 4px 6px -1px rgba(0,0,0,0.05); }
    .header { background: linear-gradient(135deg, #1e3a8a 0%, #2563eb 100%); padding: 24px; color: #ffffff; }
    .brand { font-size: 20px; font-weight: 800; letter-spacing: -0.5px; }
    .subhead { font-size: 13px; opacity: 0.9; margin-top: 4px; }
    .content { padding: 24px; }
    .greeting { font-size: 15px; margin-bottom: 20px; line-height: 1.5; }
    .section-title { font-size: 12px; font-weight: 800; letter-spacing: 0.5px; text-transform: uppercase; margin-top: 24px; margin-bottom: 10px; display: flex; align-items: center; gap: 6px; }
    .title-red { color: #dc2626; }
    .title-amber { color: #d97706; }
    .title-blue { color: #2563eb; }
    .task-card { background: #f8fafc; border-left: 4px solid #cbd5e1; border-radius: 4px 8px 8px 4px; padding: 12px; margin-bottom: 8px; font-size: 13px; }
    .card-red { border-left-color: #ef4444; background: #fef2f2; }
    .card-amber { border-left-color: #f59e0b; background: #fffbeb; }
    .card-blue { border-left-color: #3b82f6; background: #eff6ff; }
    .task-name { font-weight: 700; color: #0f172a; margin-bottom: 4px; }
    .task-meta { font-size: 11px; color: #64748b; }
    .empty-badge { font-size: 12px; color: #16a34a; font-style: italic; background: #f0fdf4; padding: 8px 12px; border-radius: 6px; }
    .footer { background: #f1f5f9; padding: 16px 24px; font-size: 11px; color: #64748b; border-top: 1px solid #e2e8f0; text-align: center; }
  </style>
</head>
<body>
  <div class="container">
    <div class="header">
      <div class="brand">UrbanGaon AI Todo Platform</div>
      <div class="subhead">Daily Executive Operational Digest • ${f}</div>
    </div>
    <div class="content">
      <div class="greeting">
        Good morning <strong>${b}</strong>,<br>
        Here is your targeted commitment ledger for today. Synchronized with zero spam.
      </div>

      <!-- Overdue Tasks -->
      <div class="section-title title-red">⚠️ Overdue Deliverables (Requires Immediate Resolution)</div>
      ${0===c.length?'<div class="empty-badge">✓ Zero overdue deliverables. Excellent punctuality!</div>':c.map(a=>`
            <div class="task-card card-red">
              <div class="task-name">${a.title}</div>
              <div class="task-meta">Scheduled: ${a.scheduledDate} at ${a.time} • Priority: ${a.priority}</div>
            </div>
          `).join("")}

      <!-- Today Tasks -->
      <div class="section-title title-amber">⏰ Deliverables Due Today</div>
      ${0===d.length?'<div class="empty-badge">No deliverables scheduled for today.</div>':d.map(a=>`
            <div class="task-card card-amber">
              <div class="task-name">${a.title}</div>
              <div class="task-meta">Execution Target: ${a.time} • Priority: ${a.priority} • Department: ${a.department}</div>
            </div>
          `).join("")}

      <!-- Upcoming Tasks -->
      <div class="section-title title-blue">📅 Upcoming Deliverables This Week</div>
      ${0===e.length?'<div class="empty-badge">No upcoming deliverables this week.</div>':e.map(a=>`
            <div class="task-card card-blue">
              <div class="task-name">${a.title}</div>
              <div class="task-meta">Due: ${a.scheduledDate} at ${a.time} • Priority: ${a.priority}</div>
            </div>
          `).join("")}
    </div>
    <div class="footer">
      Automated by UrbanGaon Dispatcher Engine • Flowchart 13 Compliance • Confidential Corporate Communication
    </div>
  </div>
</body>
</html>
  `}(a),h=process.env.SMTP_FROM||'"UrbanGaon Dispatcher" <alerts@urbangaon.com>';try{b=await c.sendMail({from:h,to:a.toEmail,subject:`📋 Daily Operational Focus: ${a.dateString} — ${a.toName}`,html:g})}catch(i){console.warn("[Live SMTP failed, falling back to Ethereal Mailbox]:",i);let c=await d.Ay.createTestAccount(),e=d.Ay.createTransport({host:"smtp.ethereal.email",port:587,secure:!1,auth:{user:c.user,pass:c.pass},connectionTimeout:8e3});f=!0,b=await e.sendMail({from:h,to:a.toEmail,subject:`📋 Daily Operational Focus: ${a.dateString} — ${a.toName}`,html:g})}let i=f?d.Ay.getTestMessageUrl(b):null;return{success:!0,messageId:b.messageId,isTestAccount:f,previewUrl:i}}async function g(a){let b,{transporter:c,isTestAccount:f}=await e(),g=function(a){let{toName:b,resetCode:c,expiresMinutes:d=15}=a;return`
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <style>
    body { font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Helvetica, Arial, sans-serif; background-color: #0f172a; color: #1e293b; margin: 0; padding: 24px 12px; }
    .container { max-width: 560px; margin: 0 auto; background: #ffffff; border-radius: 14px; border: 1px solid #e2e8f0; overflow: hidden; box-shadow: 0 10px 25px -5px rgba(0,0,0,0.15); }
    .header { background: linear-gradient(135deg, #0f172a 0%, #1e3a8a 50%, #2563eb 100%); padding: 32px 24px; color: #ffffff; text-align: center; }
    .brand { font-size: 22px; font-weight: 800; letter-spacing: -0.5px; }
    .subhead { font-size: 13px; color: #93c5fd; margin-top: 6px; font-weight: 500; }
    .content { padding: 32px 28px; }
    .greeting { font-size: 16px; margin-bottom: 16px; line-height: 1.6; color: #1e293b; }
    .intro-text { font-size: 14px; color: #475569; line-height: 1.6; margin-bottom: 24px; }
    .code-box { background: #f8fafc; border: 2px dashed #3b82f6; border-radius: 12px; padding: 24px; text-align: center; margin: 24px 0; }
    .code-label { font-size: 11px; font-weight: 800; color: #2563eb; letter-spacing: 1.5px; text-transform: uppercase; margin-bottom: 8px; }
    .code-value { font-size: 34px; font-weight: 800; color: #0f172a; letter-spacing: 8px; font-family: 'SFMono-Regular', Consolas, 'Liberation Mono', Menlo, monospace; }
    .validity-tag { font-size: 12px; color: #64748b; margin-top: 10px; font-weight: 600; }
    .instructions { background: #eff6ff; border-left: 4px solid #2563eb; border-radius: 6px; padding: 14px 16px; margin: 20px 0; font-size: 13px; color: #1e40af; line-height: 1.5; }
    .warning { font-size: 12px; color: #64748b; border-top: 1px solid #f1f5f9; padding-top: 18px; margin-top: 24px; line-height: 1.5; }
    .footer { background: #f8fafc; padding: 18px 24px; font-size: 11px; color: #64748b; border-top: 1px solid #e2e8f0; text-align: center; }
  </style>
</head>
<body>
  <div class="container">
    <div class="header">
      <div class="brand">UrbanGaon Task Register</div>
      <div class="subhead">Enterprise Identity & Access Management</div>
    </div>
    <div class="content">
      <div class="greeting">
        Hello <strong>${b}</strong>,
      </div>
      <div class="intro-text">
        A self-service request was initiated to configure or update your personal password for your corporate UrbanGaon account.
      </div>

      <div class="code-box">
        <div class="code-label">Verification One-Time Code</div>
        <div class="code-value">${c}</div>
        <div class="validity-tag">⏱ Valid for the next ${d} minutes</div>
      </div>

      <div class="instructions">
        <strong>Next Steps:</strong> Return to the UrbanGaon sign-in portal, enter this 6-digit code, and submit your desired personal password. Once set, your new password will be immediately active.
      </div>

      <div class="warning">
        🔒 <strong>Security Notice:</strong> If you did not request this verification code, please ignore this email or alert the IT Operations Desk at <a href="mailto:techdesk@urbangaon.com" style="color: #2563eb;">techdesk@urbangaon.com</a>. Never share this code with anyone.
      </div>
    </div>
    <div class="footer">
      UrbanGaon Corporate Platform • Automated Enterprise Dispatcher • Zero Spam Policy
    </div>
  </div>
</body>
</html>
  `}(a),h=process.env.SMTP_FROM||'"UrbanGaon Dispatcher" <techdesk@urbangaon.com>';try{b=await c.sendMail({from:h,to:a.toEmail,subject:`🔐 UrbanGaon Account Verification Code: ${a.resetCode}`,html:g})}catch(i){console.warn("[Live SMTP failed, falling back to Ethereal Mailbox]:",i);let c=await d.Ay.createTestAccount(),e=d.Ay.createTransport({host:"smtp.ethereal.email",port:587,secure:!1,auth:{user:c.user,pass:c.pass},connectionTimeout:8e3});f=!0,b=await e.sendMail({from:h,to:a.toEmail,subject:`🔐 UrbanGaon Account Verification Code: ${a.resetCode}`,html:g})}let i=f?d.Ay.getTestMessageUrl(b):null;return{success:!0,messageId:b.messageId,isTestAccount:f,previewUrl:i}}},86439:a=>{"use strict";a.exports=require("next/dist/shared/lib/no-fallback-error.external")},96487:()=>{}};var b=require("../../../../webpack-runtime.js");b.C(a);var c=b.X(0,[873,692,856],()=>b(b.s=27400));module.exports=c})();